package com.nsapi.niceschoolapi.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.nsapi.niceschoolapi.entity.Rescource;

public interface RescourceMapper extends BaseMapper<Rescource> {
}
