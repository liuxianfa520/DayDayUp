// 云函数入口文件
const cloud = require('wx-server-sdk')
const mysql = require('mysql2/promise')
cloud.init()

// 云函数入口函数
exports.main = async (event, context) => {
  try {
    const connection = await mysql.createConnection({
    
      host: "server.natappfree.cc",
      port:"35924",
      database: "niceschool",
      user: "root",
      password: "ln579683"
    })
    const [rows, fields] =
      await connection.execute('select * from major')
    
    return rows;
  } catch (err) {
    console.log("连接错误", err);
    return err;
  }
  const wxContext = cloud.getWXContext()

  return {
    event,
    openid: wxContext.OPENID,
    appid: wxContext.APPID,
    unionid: wxContext.UNIONID,
  }
}